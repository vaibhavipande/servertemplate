// dependencies
import express from "express"
import dotenv from "dotenv"
import ejs from "ejs"
import bodyParser from "body-parser";

// folders
import { router } from "./router/router.js"

dotenv.config({ path: "./config.env" })




let app = express()

let port = process.env.PORT || 1002

app.use(bodyParser.urlencoded({ extended: true }))

app.use(bodyParser.json())

app.use(express.static("./public"))

app.set("view engine", "ejs")

app.use(router)

app.listen(port, () => {
    console.log(`Server is running on port: http://localhost:${port} !`)
})



// sequence

// 1.imports
// 2.config
// 3.instance (app)(use)
// pubilc file (ejs should give public file access)
